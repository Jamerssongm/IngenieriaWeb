let numeros = JSON.parse(localStorage.getItem("numeros")) || [];

const input = document.getElementById("numberInput");
const btnAgregar = document.getElementById("addBtn");
const btnClasificar = document.getElementById("classifyBtn");
const btnApi = document.getElementById("apiBtn");
const btnLimpiar = document.getElementById("clearBtn");

const lista = document.getElementById("numberList");
const contenedor = document.getElementById("cardsContainer");

const totalEl = document.getElementById("countTotal");
const paresEl = document.getElementById("countEven");
const imparesEl = document.getElementById("countOdd");
const primosEl = document.getElementById("countPrime");

// Función para saber si es primo
function esPrimo(n) {
  if (n <= 1) return false;
  for (let i = 2; i < n; i++) {
    if (n % i === 0) return false;
  }
  return true;
}

// Guarda en localStorage
function guardar() {
  localStorage.setItem("numeros", JSON.stringify(numeros));
}

// lista de números con botón eliminar
function mostrarLista() {
  lista.innerHTML = "";

  if (numeros.length === 0) {
    lista.innerHTML = "<li class='empty'>No hay números ingresados.</li>";
    return;
  }

  for (let i = 0; i < numeros.length; i++) {
    let li = document.createElement("li");
    li.className = "number-item";

    li.innerHTML = `
      <span>${numeros[i]}</span>
      <button class="delete-btn" onclick="eliminarNumero(${i})">Eliminar</button>
    `;

    lista.appendChild(li);
  }
}

// Elimina por índice
function eliminarNumero(i) {
  numeros.splice(i, 1);
  guardar();
  clasificar(); // actualiza tarjetas y contadores
}

// Clasifica y crea tarjetas
function clasificar() {
  contenedor.innerHTML = "";

  let pares = 0;
  let impares = 0;
  let primos = 0;

  if (numeros.length === 0) {
    contenedor.innerHTML = "<div class='empty'>Sin datos para clasificar.</div>";
  }

  for (let i = 0; i < numeros.length; i++) {
    let n = numeros[i];
    let tipo = "";
    let clase = "";

    // prioridad primo
    if (esPrimo(n)) {
      tipo = "Primo";
      clase = "prime";
      primos++;
    } else if (n % 2 === 0) {
      tipo = "Par";
      clase = "even";
      pares++;
    } else {
      tipo = "Impar";
      clase = "odd";
      impares++;
    }

    let card = document.createElement("div");
    card.className = "card " + clase;
    card.innerHTML = `
      <div>Número: ${n}</div>
      <div class="type">Tipo: ${tipo}</div>
    `;
    contenedor.appendChild(card);
  }

  totalEl.textContent = numeros.length;
  paresEl.textContent = pares;
  imparesEl.textContent = impares;
  primosEl.textContent = primos;

  mostrarLista();
}

// Agregar número
function agregarNumero() {
  let valor = input.value;

  if (valor === "") return;

  numeros.push(Number(valor));
  input.value = "";
  guardar();
  clasificar();
}

// Eventos
btnAgregar.addEventListener("click", agregarNumero);

input.addEventListener("keydown", function (e) {
  if (e.key === "Enter") {
    agregarNumero();
  }
});

btnClasificar.addEventListener("click", clasificar);

btnApi.addEventListener("click", async function () {
  try {
    let resp = await fetch("https://jsonplaceholder.typicode.com/posts");
    let data = await resp.json();

    for (let i = 0; i < 10; i++) {
      numeros.push(data[i].id);
    }   //No fui capaz de hacer aleatorios pero agregué otros 5 numeros jajaja

    guardar();
    clasificar();
  } catch (error) {
    alert("Error cargando API");
  }
});

btnLimpiar.addEventListener("click", function () {
  let ok = confirm("¿Seguro que quieres limpiar todo?");
  if (ok) {
    numeros = [];
    guardar();
    clasificar();
  }
});

// Inicio
clasificar();